create
    definer = root@localhost procedure getCusByID(IN cusID int)
begin
select * from customers where customerNumber = cusID;
end;

