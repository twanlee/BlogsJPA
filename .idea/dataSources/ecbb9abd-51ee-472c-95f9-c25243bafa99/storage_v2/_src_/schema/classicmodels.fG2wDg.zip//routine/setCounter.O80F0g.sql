create
    definer = root@localhost procedure setCounter(INOUT counter int, IN inc int)
begin 
set counter = counter + inc;
end;

